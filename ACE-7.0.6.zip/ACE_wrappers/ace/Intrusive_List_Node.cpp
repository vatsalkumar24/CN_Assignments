#ifndef ACE_INTRUSIVE_LIST_NODE_CPP
#define ACE_INTRUSIVE_LIST_NODE_CPP

#include "ace/Intrusive_List_Node.h"

#if !defined (ACE_LACKS_PRAGMA_ONCE)
# pragma once
#endif /* ACE_LACKS_PRAGMA_ONCE */

#if !defined (__ACE_INLINE__)
#include "ace/Intrusive_List_Node.inl"
#endif /* __ACE_INLINE__ */

#endif /* ACE_INTRUSIVE_LIST_NODE_CPP */
