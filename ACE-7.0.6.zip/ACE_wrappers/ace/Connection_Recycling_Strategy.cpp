#include "ace/Connection_Recycling_Strategy.h"

ACE_BEGIN_VERSIONED_NAMESPACE_DECL

ACE_Connection_Recycling_Strategy::ACE_Connection_Recycling_Strategy ()
{
}

ACE_END_VERSIONED_NAMESPACE_DECL
