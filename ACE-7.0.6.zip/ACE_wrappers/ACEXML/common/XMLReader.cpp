#include "XMLReader.h"

ACEXML_XMLReader::~ACEXML_XMLReader (void)
{
}
