#include "ContentHandler.h"

ACEXML_ContentHandler::~ACEXML_ContentHandler (void)
{
}
