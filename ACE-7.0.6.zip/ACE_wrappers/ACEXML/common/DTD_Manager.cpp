#include "ACEXML/common/DTD_Manager.h"

ACEXML_DTD_Manager::~ACEXML_DTD_Manager ()
{

}
